<?php 
include("config.php");
if(!isset($_SESSION["user_id"]) || $_SESSION["user_id"]==""){
	header("Location: login.php");
}
?>
<a href="logout.php">Logout</a>&nbsp;&nbsp;<a href="upload_excel.php">Upload Excel</a>&nbsp;&nbsp;<a href="list_excel.php">Excel List</a>&nbsp;&nbsp;<a href="list_excel_data.php">Excel Data List</a>
<h3>Welcome to admin</h3>