<?php 
include("config.php");
if(!isset($_SESSION["user_id"]) || $_SESSION["user_id"]==""){
	header("Location: login.php");
}
?>
<a href="logout.php">Logout</a>&nbsp;&nbsp;<a href="upload_excel.php">Upload Excel</a>&nbsp;&nbsp;<a href="list_excel.php">Excel List</a>&nbsp;&nbsp;<a href="list_excel_data.php">Excel Data List</a>
<table>
<tr>
<td>File Name</td>
<td>Name</td>
<td>Phone</td>
</tr>
<?php 
$result=mysqli_query($connect,"select * from excel_data");
while($row=mysqli_fetch_array($result)){
	echo '<tr>
<td><a href="uploads/'.$row["sheet_name"].'" download>'.$row["sheet_name"].'</a></td>
<td>'.$row["name"].'</td>
<td>'.$row["phone"].'</td>
</tr>';
} ?>

</table>