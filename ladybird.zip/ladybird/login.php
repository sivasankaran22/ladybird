<?php 
include("config.php");
if(isset($_POST["submit"])){
	$email =mysqli_real_escape_string($connect,$_POST["email"]);
	$password =mysqli_real_escape_string($connect,$_POST["password"]);
	$select_email=mysqli_query($connect,"SELECT * FROM `user` where email='".$email."'");
	if(mysqli_num_rows($select_email)==1){	
	$resulr=mysqli_fetch_array($select_email);
	if(password_verify($password,$resulr["password"])){	
		$_SESSION["user_id"]=$email;
		header("Location: dashboard.php");
	}else{
		
	echo "<script>alert('Email Id OR Password Incorrect');</script>";
	}
	}else{
		echo "<script>alert('Email Id OR Password Incorrect');</script>";
	}
}
?>
<a href="login.php">Login</a>&nbsp;&nbsp;<a href="index.php">Signup</a>
<form method="post"><br>
<input type="text" name="email" placeholder="Email"><br>
<input type="password" name="password" placeholder="Password"><br>
<input type="submit" name="submit" value="Login"><br>
</form>