<?php 
include("config.php");
if(isset($_POST["submit"])){
	$name =mysqli_real_escape_string($connect,$_POST["name"]);
	$email =mysqli_real_escape_string($connect,$_POST["email"]);
	$password =mysqli_real_escape_string($connect,$_POST["password"]);
	$select_email=mysqli_query($connect,"SELECT * FROM `user` where email='".$email."'");
	if(mysqli_num_rows($select_email)==0){		
	mysqli_query($connect,"INSERT INTO `user`(`name`, `email`, `password`) VALUES ('".$name."','".$email."','".password_hash($password, PASSWORD_DEFAULT)."')");
		echo "<script>alert('Successfully registred');</script>";
	}else{
		echo "<script>alert('Email Id already existed');</script>";
	}
}
?>
<a href="login.php">Login</a>&nbsp;&nbsp;<a href="index.php">Signup</a>
<form method="post"><br>
<input type="text" name="name" placeholder="Name"><br>
<input type="text" name="email" placeholder="Email"><br>
<input type="password" name="password" placeholder="Password"><br>
<input type="submit" name="submit" value="Signup"><br>
</form>