<?php 
include("config.php");
include("SimpleXLSX.php");
if(!isset($_SESSION["user_id"]) || $_SESSION["user_id"]==""){
	header("Location: login.php");
}
if(isset($_POST["submit"])){
	  $file_tmp =$_FILES['fname']['tmp_name'];
	  $file_name =$_FILES['fname']['name'];
      $file_ext=explode('.',$file_name);
	  $extensions= array("xlsx","XLSX");
	if(in_array(end($file_ext),$extensions) === true){	
	move_uploaded_file($file_tmp,"uploads/".$file_name);	
	mysqli_query($connect,"INSERT INTO `excel`(`file`) VALUES ('".$file_name."')");
	if ( $xlsx = SimpleXLSX::parse('uploads/'.$file_name) ) {
		$i=0;
		 foreach($xlsx->rows() as $key){
			 if($i==0){ $i++; continue;} 
			mysqli_query($connect,"INSERT INTO `excel_data`(`name`, `phone`, `sheet_name`) VALUES ('".$key[0]."','".$key[1]."','".$file_name."')");
		 }
	}
	
		echo "<script>alert('Successfully Upload');</script>";
	}else{
		echo "<script>alert('Please upload valid file');</script>";
	}
}
?>
<a href="logout.php">Logout</a>&nbsp;&nbsp;<a href="upload_excel.php">Upload Excel</a>&nbsp;&nbsp;<a href="list_excel.php">Excel List</a>&nbsp;&nbsp;<a href="list_excel_data.php">Excel Data List</a>
<form method="post" enctype="multipart/form-data"><br>
<label>Upload Excel</label><br>
<input type="File" name="fname"><br>
<input type="submit" name="submit" value="Upload"><br>
</form>