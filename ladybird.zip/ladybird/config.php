<?php 

$connect=mysqli_connect("localhost","root","","lady_bird");
if(!session_start())
	session_start();